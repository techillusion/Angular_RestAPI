export class user
{
    firstname:string;
    lastname:string;
}