import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { ExcelService } from '../excel.service';
import { from } from 'rxjs';
@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent {
  post: any;
  baseUrl = "http://localhost/Kstore-V1.0/authen/api/api_banner.php";
  constructor(private httpClient: HttpClient, private excelService: ExcelService) { }
  getPost() {
    this.httpClient.get(this.baseUrl).subscribe((res) => {
      console.log(res.data);
      this.post = res;
    });
  }
  exportAsXLSX(): void {
    this.excelService.exportAsExcelFile(this.post, 'sample');
  }
}
