import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {user} from "./user.model";

@Injectable({
  providedIn: 'root'
})
export class DataService {

 baseUrl='https://jsonplaceholder.typicode.com/todos/1';
  constructor( private _http: HttpClient  ) { }

 public getUser()
  {
    return this._http.get<user[]>(this.baseUrl);
  }
}
