import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { InsertService } from '../insert.service'
import { from } from 'rxjs';
import { user } from '../user.model';
import { ValuesService } from '../values.service';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent  {
  constructor ( private http:HttpClient)
  {

  }
  profileForm = new FormGroup({
    firstName: new FormControl(''),
    lastName: new FormControl(''),
  });

user = new user();
  
onSubmit(){
 console.log(this.profileForm.value)
}

}
